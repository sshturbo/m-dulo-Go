#!/bin/bash

gerar_email_aleatorio() {
    tamanho=$1
    dominio="gmail.com"
    caracteres=($(echo {a..z} {A..Z} {0..9}))
    email_local=""
    for ((i=0;i<tamanho;i++)); do
        index=$(( $RANDOM % ${#caracteres[@]} ))
        email_local+="${caracteres[$index]}"
    done
    echo "${email_local}@${dominio}"
}

adicionar_usuario_sistema() {
    username=$1
    password=$2
    dias=$3
    sshlimiter=$4

    # Verificar se o usuário existe e criar se não existir
    if ! id "$username" &>/dev/null; then
        final=$(date -d "+$dias days" +"%Y-%m-%d")
        useradd -e "$final" -M -s /bin/false -p "$password" "$username"
        senha_path="/etc/SSHPlus/senha/$username"
        echo "$password" > "$senha_path"
        echo "$username $sshlimiter" >> /root/usuarios.db
    fi
}

adicionar_uuid_ao_v2ray() {
    uuid=$1
    nome_usuario=$2
    dias=$3
    config_file="/etc/v2ray/config.json"
    email=$(gerar_email_aleatorio 10)
    data_validade=$(date -d "+$dias days" +"%Y-%m-%d")

    # Adicionar o novo UUID ao arquivo de configuração
    novo_cliente="{\"id\":\"$uuid\",\"alterId\":0,\"email\":\"$email\"}"
    jq ".inbounds[0].settings.clients += [$novo_cliente]" "$config_file" > temp && mv temp "$config_file"

    # Adicionar informações ao arquivo de registro
    nome_arquivo_registro="/etc/SSHPlus/RegV2ray"
    registro="$uuid | $nome_usuario | $data_validade"
    echo "$registro" >> "$nome_arquivo_registro"
}

if [ $# -lt 4 ]; then
    echo "Erro: Argumentos insuficientes."
    exit 1
fi

username=$1
password=$2
dias=$3
sshlimiter=$4
uuid=$5

adicionar_usuario_sistema "$username" "$password" "$dias" "$sshlimiter"

if [ ! -z "$uuid" ]; then
    adicionar_uuid_ao_v2ray "$uuid" "$username" "$dias"
fi

# Reiniciar o serviço V2Ray (ajuste o comando conforme necessário)
systemctl restart v2ray
echo "Conta de usuário e V2Ray (se aplicável) criadas com sucesso."
