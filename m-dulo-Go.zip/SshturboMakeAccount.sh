#!/bin/bash

# Função para gerar um e-mail aleatório
gerar_email_aleatorio() {
    tamanho=$1
    dominio="gmail.com"
    caracteres=($(echo {a..z} {A..Z} {0..9}))
    email_local=""
    for ((i=0; i<tamanho; i++)); do
        index=$(( $RANDOM % ${#caracteres[@]} ))
        email_local+="${caracteres[$index]}"
    done
    echo "${email_local}@${dominio}"
}

# Função para adicionar um usuário ao sistema
adicionar_usuario_sistema() {
    username=$1
    password=$2
    dias=$3
    sshlimiter=$4

    # Verificar se o usuário já existe
    if id "$username" &>/dev/null; then
        echo "Usuário '$username' já existe. Nenhuma ação realizada."
        return 0
    fi

    final=$(date "+%Y-%m-%d" -d "+$dias days")
    pass=$(perl -e 'print crypt($ARGV[0], "password")' $password)
    useradd -e "$final" -M -s /bin/false -p "$pass" "$username" 2>/dev/null

    # Registrar no banco de dados
    echo "$username $sshlimiter" >> /root/usuarios.db
    echo "$password" > /etc/SSHPlus/senha/"$username"
}

# Função para adicionar UUID ao V2Ray
adicionar_uuid_ao_v2ray() {
    uuid=$1
    nome_usuario=$2
    dias=$3
    config_file="/etc/v2ray/config.json"
    email=$(gerar_email_aleatorio 10)
    data_validade=$(date -d "+$dias days" +"%Y-%m-%d")

    # Verificar se o arquivo JSON é válido
    if ! jq empty "$config_file" > /dev/null 2>&1; then
        echo "Erro: O arquivo de configuração '$config_file' não é um JSON válido."
        exit 1
    fi

    # Verificar se o UUID já existe no arquivo
    if jq -e ".inbounds[0].settings.clients[] | select(.id == \"$uuid\")" "$config_file" > /dev/null; then
        echo "UUID '$uuid' já existe. Nenhuma ação realizada."
        return 0
    fi

    # Criar um novo cliente
    novo_cliente="{\"id\":\"$uuid\",\"alterId\":0,\"email\":\"$email\"}"

    # Adicionar o cliente ao JSON
    temp_file=$(mktemp)
    if jq ".inbounds[0].settings.clients += [$novo_cliente]" "$config_file" > "$temp_file"; then
        cp "$config_file" "${config_file}.bak" # Criar backup
        mv "$temp_file" "$config_file"
        echo "UUID adicionado ao V2Ray com sucesso."
    else
        echo "Erro ao atualizar o arquivo de configuração '$config_file'."
        rm -f "$temp_file"
        exit 1
    fi

    # Registrar informações do usuário no V2Ray
    nome_arquivo_registro="/etc/SSHPlus/RegV2ray"
    registro="$uuid | $nome_usuario | $data_validade"
    echo "$registro" >> "$nome_arquivo_registro"
}

# Verificar argumentos suficientes
if [ $# -lt 4 ]; then
    echo "Erro: Argumentos insuficientes."
    echo "Uso: $0 <username> <password> <dias> <sshlimiter> [uuid]"
    exit 1
fi

# Coletar argumentos
username=$1
password=$2
dias=$3
sshlimiter=$4
uuid=$5

# Criar conta de usuário no sistema e opcionalmente no V2Ray
if [ -z "$uuid" ]; then
    adicionar_usuario_sistema "$username" "$password" "$dias" "$sshlimiter"
else
    adicionar_usuario_sistema "$username" "$password" "$dias" "$sshlimiter"
    adicionar_uuid_ao_v2ray "$uuid" "$username" "$dias"
fi

# Reiniciar o serviço V2Ray
if systemctl restart v2ray; then
    echo "V2Ray reiniciado com sucesso."
else
    echo "Erro ao reiniciar o serviço V2Ray."
fi

echo "Conta de usuário e configuração do V2Ray (se aplicável) concluídas com sucesso."
