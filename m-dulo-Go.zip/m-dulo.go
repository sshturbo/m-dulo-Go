package main

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"time"
)

const (
	baseScriptsFolder = "scripts"
	serverPort        = ":8040"
)

func executeQueue(routeName string) {
	folderPath := filepath.Join(baseScriptsFolder, routeName)
	os.MkdirAll(folderPath, os.ModePerm)

	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		files, err := filepath.Glob(filepath.Join(folderPath, "*.sh"))
		if err != nil {
			logError("Erro ao listar arquivos", err)
			continue
		}

		if len(files) > 0 {
			filePath := filepath.Join(folderPath, files[0])
			cmd := exec.Command("bash", filePath)
			err := cmd.Run()
			if err != nil {
				logError("Erro ao executar o arquivo", err)
			} else {
				fmt.Printf("Script executado com sucesso: %s\n", filePath)
				os.Remove(filePath) // Move a exclusão para cá, após a execução bem-sucedida
			}
		}
	}
}

func handleSpecificScript(w http.ResponseWriter, r *http.Request, routeName string, expectedFilename string) {
	r.ParseMultipartForm(10 << 20) // 10 MB limite de tamanho do arquivo
	file, handler, err := r.FormFile("file")

	if err != nil {
		http.Error(w, "Erro ao obter o arquivo", http.StatusBadRequest)
		logError("Erro ao obter o arquivo", err)
		return
	}
	defer file.Close()

	if handler.Filename == "" {
		http.Error(w, "Nenhum arquivo selecionado", http.StatusBadRequest)
		return
	}

	if expectedFilename != "" && handler.Filename != expectedFilename {
		http.Error(w, fmt.Sprintf("Nome de arquivo inválido. Esperava-se %s.", expectedFilename), http.StatusBadRequest)
		return
	}

	if filepath.Ext(handler.Filename) != ".sh" {
		http.Error(w, "Apenas arquivos com extensão .sh são aceitos.", http.StatusBadRequest)
		return
	}

	folderPath := filepath.Join(baseScriptsFolder, routeName)
	os.MkdirAll(folderPath, os.ModePerm)

	filePath := filepath.Join(folderPath, handler.Filename)
	dst, err := os.Create(filePath)
	if err != nil {
		http.Error(w, fmt.Sprintf("Erro ao criar o arquivo: %s", err), http.StatusInternalServerError)
		logError("Erro ao criar o arquivo", err)
		return
	}
	defer dst.Close()

	io.Copy(dst, file)

	cmd := exec.Command("bash", filePath)
	err = cmd.Run()
	if err != nil {
		http.Error(w, fmt.Sprintf("Erro ao executar o arquivo: %s", err), http.StatusInternalServerError)
		logError("Erro ao executar o arquivo", err)
		return
	}

	os.Remove(filePath) // Exclusão após a execução bem-sucedida

	w.WriteHeader(http.StatusOK)
	w.Write([]byte("A sincronização foi iniciada com sucesso!"))
}

func logError(message string, err error) {
	fmt.Printf("Erro: %s: %s\n", message, err)
}

func main() {
	r := http.NewServeMux()

	r.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		html := `
		<!DOCTYPE html>
		<html lang="pt-br">
		<head>
			<meta charset="UTF-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<title>Painel Web Pro</title>
			<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
			<style>
				body {
					font-family: Arial, sans-serif;
					background: linear-gradient(to right, #6A82FB, #FC5C7D);
					height: 100vh;
					color: white;
				}
				.card {
					background-color: rgba(0, 0, 0, 0.7);
					border-radius: 20px;
					box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
				}
				img.logo {
					width: 250px;
					margin-bottom: 15px;
				}
			</style>
		</head>
		<body>
			<div class="container mt-5">
				<div class="row justify-content-center align-items-center" style="height: 80vh;">
					<div class="col-md-6">
						<div class="card text-center p-4">
							<img src="https://i.imgur.com/p2aMFi7.png" alt="Logo" class="logo mx-auto">
							<h2 class="card-title mb-4">Bem-vindo ao Painel Web Pro</h2>
							<p class="card-text mb-3">Meus parabéns, os módulos foram instalados com sucesso!</p>
							<p class="card-text">Agora você pode estar criando, editando e excluindo usuários com a eficiência que só o Painel Web Pro pode oferecer.</p>
							<a href="https://t.me/painelprooficial" target="_blank" class="btn btn-light mt-4">Junte-se ao Grupo do Telegram</a>
						</div>
					</div>
				</div>
			</div>
			<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
		</body>
		</html>
		`
		w.Write([]byte(html))
	})

	r.HandleFunc("/editar", func(w http.ResponseWriter, r *http.Request) {
		handleSpecificScript(w, r, "editar", "editar.sh")
	})

	r.HandleFunc("/deletar", func(w http.ResponseWriter, r *http.Request) {
		handleSpecificScript(w, r, "deletar", "deletar.sh")
	})

	r.HandleFunc("/criar", func(w http.ResponseWriter, r *http.Request) {
		handleSpecificScript(w, r, "criar", "")
	})

	r.HandleFunc("/online", func(w http.ResponseWriter, r *http.Request) {
		handleSpecificScript(w, r, "online", "")
	})

	fmt.Printf("Servidor Go está ativo em http://localhost%s\n", serverPort)

	go executeQueue("editar")
	go executeQueue("deletar")
	go executeQueue("criar")
	http.ListenAndServe(serverPort, r)
}
