package main

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"time"
)

const (
	baseScriptsFolder = "scripts"
	serverPort        = ":8040"
)

func executeQueue(routeName string) {
	folderPath := filepath.Join(baseScriptsFolder, routeName)
	os.MkdirAll(folderPath, os.ModePerm)

	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		files, err := filepath.Glob(filepath.Join(folderPath, "*.sh"))
		if err != nil {
			logError("Erro ao listar arquivos", err)
			continue
		}

		if len(files) > 0 {
			filePath := filepath.Join(folderPath, files[0])
			cmd := exec.Command("bash", filePath)
			err := cmd.Run()
			if err != nil {
				logError("Erro ao executar o arquivo", err)
			} else {
				fmt.Printf("Script executado com sucesso: %s\n", filePath)
				os.Remove(filePath) // Move a exclusão para cá, após a execução bem-sucedida
			}
		}
	}
}

func handleSpecificScript(w http.ResponseWriter, r *http.Request, routeName string, expectedFilename string) {
	r.ParseMultipartForm(10 << 20) // 10 MB limite de tamanho do arquivo
	file, handler, err := r.FormFile("file")

	if err != nil {
		http.Error(w, "Erro ao obter o arquivo", http.StatusBadRequest)
		logError("Erro ao obter o arquivo", err)
		return
	}
	defer file.Close()

	if handler.Filename == "" {
		http.Error(w, "Nenhum arquivo selecionado", http.StatusBadRequest)
		return
	}

	if expectedFilename != "" && handler.Filename != expectedFilename {
		http.Error(w, fmt.Sprintf("Nome de arquivo inválido. Esperava-se %s.", expectedFilename), http.StatusBadRequest)
		return
	}

	if filepath.Ext(handler.Filename) != ".sh" {
		http.Error(w, "Apenas arquivos com extensão .sh são aceitos.", http.StatusBadRequest)
		return
	}

	folderPath := filepath.Join(baseScriptsFolder, routeName)
	os.MkdirAll(folderPath, os.ModePerm)

	filePath := filepath.Join(folderPath, handler.Filename)
	dst, err := os.Create(filePath)
	if err != nil {
		http.Error(w, fmt.Sprintf("Erro ao criar o arquivo: %s", err), http.StatusInternalServerError)
		logError("Erro ao criar o arquivo", err)
		return
	}
	defer dst.Close()

	io.Copy(dst, file)

	cmd := exec.Command("bash", filePath)
	err = cmd.Run()
	if err != nil {
		http.Error(w, fmt.Sprintf("Erro ao executar o arquivo: %s", err), http.StatusInternalServerError)
		logError("Erro ao executar o arquivo", err)
		return
	}

	os.Remove(filePath) // Exclusão após a execução bem-sucedida

	w.WriteHeader(http.StatusOK)
	w.Write([]byte("A sincronização foi iniciada com sucesso!"))
}

func logError(message string, err error) {
	fmt.Printf("Erro: %s: %s\n", message, err)
}

func main() {
    r := http.NewServeMux()

    // Servir arquivos estáticos CSS e imagens
    fs := http.FileServer(http.Dir("assets"))
    http.Handle("/assets/", http.StripPrefix("/assets/", fs))

    // Servir arquivos HTML
    r.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
        http.ServeFile(w, r, "templates/index.html")
    })

    // Roteamento para manipular scripts específicos
    r.HandleFunc("/editar", func(w http.ResponseWriter, r *http.Request) {
        handleSpecificScript(w, r, "editar", "editar.sh")
    })

    r.HandleFunc("/deletar", func(w http.ResponseWriter, r *http.Request) {
        handleSpecificScript(w, r, "deletar", "deletar.sh")
    })

    r.HandleFunc("/criar", func(w http.ResponseWriter, r *http.Request) {
        handleSpecificScript(w, r, "criar", "")
    })

    r.HandleFunc("/online", func(w http.ResponseWriter, r *http.Request) {
        handleSpecificScript(w, r, "online", "")
    })

    fmt.Printf("Servidor Go está ativo em http://localhost%s\n", serverPort)

    go executeQueue("editar")
    go executeQueue("deletar")
    go executeQueue("criar")
    http.ListenAndServe(serverPort, r)
}
